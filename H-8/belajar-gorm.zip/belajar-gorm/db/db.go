package db

import (
	"app/model"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

var Con *gorm.DB

func Connect() {
	db, err := gorm.Open(postgres.Open("user=postgres password=123123 host=db.rpofflhghfckeaquktms.supabase.co port=5432 dbname=company"))
	if err != nil {
		panic(err)
	}

	Con = db

	err = Con.AutoMigrate(
		&model.Product{},
	)
	if err != nil {
		panic(err)
	}

}
